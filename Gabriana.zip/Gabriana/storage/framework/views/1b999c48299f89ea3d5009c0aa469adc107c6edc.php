<?php $__env->startSection('content'); ?>

<!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
	    Patients Today
	</h1>
	<ol class="breadcrumb">
        <li><a href="<?php echo e(url('/assistant')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="">Reports</li>
        <li class="active">Patients</li>
    </ol>
</section>
<section class="content">
	<div class="row">
        <div class="col-xs-12">
            <div class="box">
            <!-- /.box-header -->
                <div class="box-body">
                    <table id="example" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Service Rendered</th>
                                <th>Dentist</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($schedules) > 1): ?>
                                <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($schedule->date == $today and $schedule->opStatus == 'Done'): ?>
                                        <tr>
                                            <td><?php echo e($schedule->patient->name); ?></td>
                                            <td><?php echo e($schedule->service->servName); ?></td>
                                            <td><?php echo e($schedule->dentist->name); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p>No Patient Found</p>
                            <?php endif; ?>                                
                        </tbody>
                    </table>

                </div>
                
            </div>
        </div>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.assistantLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>