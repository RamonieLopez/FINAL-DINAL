<?php $__env->startSection('content'); ?>
<section class="content-header">
   <h1>
      <?php echo e($patient->name); ?>

   </h1>
   <ol class="breadcrumb">
      <li><a href=<?php echo e(url('/assistant')); ?>><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="<?php echo e(url('/assistant/patient')); ?>">Records</a></li>
   </ol>
</section>
<!-- Main content -->
<section class="content">
   <div class="row">
      <div class="col-md-12">
         <div class="box">
            <div class="box-header with-border">
               <h3 class="box-title">Patient Information</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
               <table class="table table-bordered">
                    <tbody>
                        <tr>
                            <th>Name</th>
                            <td><?php echo e($patient->name); ?></td>
                        </tr>
                        <tr>
                            <th>Address</th>
                            <td><?php echo e($patient->address); ?></td>
                        </tr>
                        <tr>
                            <th>Occupation</th>
                            <td><?php echo e($patient->occupation); ?></td>
                        </tr>
                        <tr>
                            <th>Contact Number</th>
                            <td><?php echo e($patient->patientTelNo); ?></td>
                        </tr>
                        <tr>
                            <th>Civil Status</th>
                            <td><?php echo e($patient->status); ?></td>
                        </tr>
                        <tr>
                            <th>Date of Birth</th>
                            <td><?php echo e($patient->birthDate); ?></td>
                        </tr>
                        <tr>
                            <th>Age</th>
                            <td><?php echo e($patient->age); ?></td>
                        </tr>
                        <tr>
                            <th>Gender</th>
                            <td><?php echo e($patient->sex); ?></td>
                        </tr>
                        <tr>
                            <th>Medical Conditions</th>
                            <td><?php echo e($patient->medconditions); ?></td>
                        </tr>
                        <tr>
                            <th>Allergies</th>
                            <td><?php echo e($patient->allergies); ?></td>
                        </tr>
                        <tr>
                            <th>Balance</th>
                            <td><?php echo e($patient->balance); ?></td>
                        </tr>
                        </tr>
                        <tr>
                            <th>Patient Status</th>
                            <td><?php echo e($patient->patStatus); ?></td>
                        </tr>
                        <tr>
                            <th>Teeth History</th>
                            <td><a href="<?php echo e(url('/assistant/patient' . '/' .$patient->patID . '/history')); ?>" class="btn btn-primary"><i class="fa fa-pencil" ></i> View teeth history </a></td>
                        </tr>
                    </tbody>
               </table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer">
               <a href="<?php echo e(url('/assistant/patient')); ?>" class="btn btn-warning">Back</a>
               <a href="<?php echo e(url('/assistant/patient' . '/' .$patient->patID . '/pay')); ?>" class="btn btn-success pull-right" style="margin: 0 10px">Pay</a>
               <a href="<?php echo e(url('/assistant/patient' . '/' .$patient->patID . '/edit')); ?>" class="btn btn-primary pull-right">Edit</a>
            </div>
         </div>
         <!-- /.box -->
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.assistantLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>