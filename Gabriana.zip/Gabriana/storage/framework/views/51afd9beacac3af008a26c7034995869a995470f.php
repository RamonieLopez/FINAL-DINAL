<?php $__env->startSection('content'); ?>
<!-- Content Header (Page header) -->
	<section class="content-header">
		<h1>
			Inventory
		</h1>
		<ol class="breadcrumb">
			<li><a href="<?php echo e(url('/admin')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
			<li class="active">Inventory</li>
		</ol>
	</section>


	<!-- Main content -->
	<section class="content">
		<div class="row">
		<div class="col-xs-12">
			<div class="box">
			<!-- /.box-header -->
			<div class="box-body">
				<table id="example1" class="table table-bordered table-striped table-responsive">
				<thead>
				<tr>
					<th>Name</th>
					<th>Quantity</th>
					<th>Unit</th>
					<th>Inventory Status</th>
					<th>Status</th>
					<th>Options</th>
				</tr>
				</thead>
				<tbody>
					<?php if(count($inventory) > 1): ?>
					<?php $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($item->invName); ?></td>
						<td><?php echo e($item->quantity); ?></td>
						<td><?php echo e($item->unit); ?></td>
						<td><?php echo e($item->invStatus); ?></td>
						<td><?php echo e($item->status); ?></td>
						<td>
						<center>
							<a href="<?php echo e(url('admin/inventory/' . $item->invID)); ?>" title="View Inventory"><button class="btn btn-info "><i class="fa fa-eye" aria-hidden="true"></i>  View</button></a>
							<?php echo Form::open(['action' => ['Admin\InventoryController@destroy', $item->invID], 'method' => 'POST']); ?>

								<?php echo e(Form::hidden('_method', 'DELETE')); ?>

								<button class="btn btn-danger pull-right" type="submit" style="margin: 2px"><i class="fa fa-trash"></i> Deactivate</button>
							<?php echo Form::close(); ?>	
						</center>					
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
					<p>No Inventory Found</p>
					<?php endif; ?>
				</tbody>
				<tfoot>
				<tr>
					<th>Name</th>
					<th>Quantity</th>
					<th>Unit</th>
					<th>Inventory Status</th>
					<th>Status</th>
					<th>Options</th>
				</tr>
				</tfoot>
				</table>
			</div>
			<!-- /.box-body -->
			</div>
			<!-- /.box -->
		</div>
		<!-- /.col -->
		</div>
		<!-- /.row -->
	</section>
	<!-- /.content -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>