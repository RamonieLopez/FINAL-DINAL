<?php $__env->startSection('content'); ?>
<section class="content-header">
   <h1>
      <?php echo e($patient->name); ?>

   </h1>
   <ol class="breadcrumb">
      <li><a href=<?php echo e(url('/assistant')); ?>><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="<?php echo e(url('/assistant/patient')); ?>">Records</a></li>
   </ol>
</section>
<!-- Main content -->
<section class="content">
   <div class="row">
      <div class="col-md-12">
         <div class="box">
            <div class="box-header with-border">
               <h3 class="box-title">Schedules</h3>
            </div>                
            <div class="box-body">
                <table id="example1" class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Services</th>
                            <th>Dentist</th>
                            <th>Balance</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $counter = 0 ?>
                    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->opStatus == 'Ongoing'): ?>
                        <?php $counter++ ?>
                        <tr>
                            <td><?php echo e($item->date); ?></td>
                            <td><?php echo e($item->service->servName); ?></td>
                            <td><?php echo e($item->dentist->name); ?></td>
                            <td><?php echo e($item->balance); ?></td>
                            <td>
                                <button class="btn btn-success btn-sm" style="margin: 2px" data-toggle="modal" data-target="#modalCart<?php echo e($counter); ?>" ><i class="fa fa-check" ></i>&nbsp;Pay</button>
                                <div class="modal fade" id="modalCart<?php echo e($counter); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <!--Header-->
                                            <div class="modal-header">
                                                <h1 class="modal-title" id="myModalLabel"><?php echo e($patient->name); ?></h1>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">×</span>
                                                </button>
                                            </div>
                                            <!--Body-->
                                            <div class="modal-body">
                                                <h3><?php echo e($item->service->servName); ?></h3>
                                                <?php echo Form::open(['action' => ['Assistant\\PatientsController@ongoing',  $item->schedId], 'method' => 'POST']); ?>

                                                    <div class="form-group" <?php echo e($errors->has('patID') ? 'has-error' : ''); ?>>
                                                        <input type="hidden" name="patID" value="<?php echo e($item->patient->patID); ?>">
                                                    </div>
                                                    <div class="form-group" <?php echo e($errors->has('dentID') ? 'has-error' : ''); ?>>
                                                        <input type="hidden" name="dentID" value="<?php echo e($item->dentist->dentID); ?>">
                                                    </div>
                                                    <div class="form-group" <?php echo e($errors->has('date') ? 'has-error' : ''); ?>>
                                                        <input type="hidden" name="date" value="<?php echo e($item->date); ?>">
                                                    </div>
                                                    <div class="form-group" <?php echo e($errors->has('timeFrom') ? 'has-error' : ''); ?>>
                                                        <input type="hidden" name="timeFrom" value="<?php echo e($item->timeFrom); ?>">
                                                    </div>
                                                    <div class="form-group" <?php echo e($errors->has('timeTo') ? 'has-error' : ''); ?>>
                                                        <input type="hidden" name="timeTo" value="<?php echo e($item->timeTo); ?>">
                                                    </div>
                                                    <div class="form-group" <?php echo e($errors->has('teethID') ? 'has-error' : ''); ?>>
                                                        <input type="hidden" name="teethID" value="<?php echo e($item->teethID); ?>">
                                                    </div>
                                                    <div class="form-group" <?php echo e($errors->has('servID') ? 'has-error' : ''); ?>>
                                                        <input type="hidden" name="servID" value="<?php echo e($item->servID); ?>">
                                                    </div>     
                                                    <div class="form-group">
                                                        <?php echo e(Form::label('price', 'Amount to be Paid')); ?>

                                                        <?php echo e(Form::text('price', $item->balance, ['class' => 'form-control', 'placeholder' => 'Total price of services'])); ?>

                                                    </div>
                                                    <div class="form-group">
                                                        <?php echo e(Form::label('payment', 'Payment')); ?>

                                                        <?php echo e(Form::text('payment', '', ['class' => 'form-control', 'placeholder' => 'Payment Amount'])); ?>

                                                    </div>
                                                <?php echo e(Form::hidden('_method', 'PUT')); ?>

                                            </div>
                                            <!--Footer-->
                                            <div class="modal-footer">
                                                <?php echo e(Form::submit('Pay', ['class'=>'btn btn-success pull-right'])); ?>

                                            <?php echo Form::close(); ?>

                                            
                                                <button type="button" class="btn btn-warning pull-left" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="box-footer">
                <a href="<?php echo e(url('/assistant/patient'. '/' .$patient->patID)); ?>" class="btn btn-warning">Back</a>
             </div>
         </div>
         <!-- /.box -->
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.assistantLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>