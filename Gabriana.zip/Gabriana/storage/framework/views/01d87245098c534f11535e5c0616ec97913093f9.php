<?php $__env->startSection('content'); ?>

<section class="content-header">
    <h1>
       Cancelled Schedules
    </h1>
    <ol class="breadcrumb">
        <li><a href="/assistant"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Schedule</li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <br>
            <br>
            <div class="box">
            <div class="box-body">
                
                <br>
                <br>
                <div>
                    <table id="example1" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Patient Name</th>
                                <th>Date of Schedule</th>
                                <th>Services</th>
                                <th>Dentist</th>
                                <th><center>Actions</center></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->opStatus == 'Cancelled'): ?>
                            <tr>
                                <td><?php echo e($item->patient->name); ?></td>
                                <td><?php echo e($item->date); ?></td>
                                <td><?php echo e($item->service->servName); ?></td>
                                <td><?php echo e($item->dentist->name); ?></td>
                                <td>
                                    <center>
                                    <a href="<?php echo e(url('/assistant/schedules/' . $item->schedId . '/view')); ?>" title="View Schedule"><button class="btn btn-success btn-sm" onclick="return confirm(&quot;Confirm delete?&quot;"><i class="fa fa-check" aria-hidden="true"></i> View</button></a>

                                </center>
                                </td>
                            </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    
                </div>

                
            </div>
        </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.assistantLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>