<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Schedule <?php echo e($schedule->id); ?>

        </h1>
        <ol class="breadcrumb">
            <li><a href="/admin"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Schedule</li>
        </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body">
                        <div class="table-responsive">
                            <table class="table">
                                    <tbody>
                                        <tr>
                                            <th> Name </th>
                                            <td> <?php echo e($schedule->patient->name); ?>  </td>
                                        </tr>
                                        <tr>
                                            <th> Date </th>
                                            <td> <?php echo e($schedule->date); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> Time From </th>
                                            <td> <?php echo e($schedule->timeFrom); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> Time To </th>
                                            <td> <?php echo e($schedule->timeTo); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> Service </th>
                                            <td> <?php echo e($schedule->service->servName); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> Dentist </th>
                                            <td> <?php echo e($schedule->dentist->name); ?> </td>
                                        </tr>
                                        <tr>
                                            <th> Operation Status </th>
                                            <td> <?php echo e($schedule->opStatus); ?> </td>
                                        </tr>
                                    </tbody>
                            </table>
                        </div>
                        <div class="box-footer">
                            <a href="<?php echo e(url('/admin/schedules')); ?>" title="Back"><button class="btn btn-warning btn-sm pull-left"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                            <form method="POST" action="<?php echo e(url('admin/schedules' . '/' . $schedule->schedID)); ?>" accept-charset="UTF-8" style="display:inline">
                                <?php echo e(method_field('DELETE')); ?>

                                <?php echo e(csrf_field()); ?>

                                <button type="submit" class="btn btn-danger btn-sm pull-right" title="Delete Schedule" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete </button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>