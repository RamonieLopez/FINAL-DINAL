<?php $__env->startSection('content'); ?>

        <section class="content-header">
            <h1>
                Create Service
            </h1>
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/assistant')); ?>"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class=""><a href="<?php echo e(url('/assistant/service')); ?>">Services</a></li>
                <li class="active">Create</li>
            </ol>
        </section>
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="box">
                    <div class="box-body">
                        <?php echo Form::open(['action' => 'Assistant\\ServicesController@store', 'method' => 'POST']); ?>

                            <div class="form-group">
                                <?php echo e(Form::label('servName', 'Service Name')); ?>

                                <?php echo e(Form::text('servName', '', ['class' => 'form-control', 'placeholder' => 'Enter Service'])); ?>

                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('price', 'Price')); ?>

                                <?php echo e(Form::text('price', '', ['class' => 'form-control', 'placeholder' => 'Enter Price'])); ?>

                            </div>
                            <div class="box-footer">
                                <?php echo e(Form::submit('Submit', ['class'=>'btn btn-success pull-right'])); ?>

                                <?php echo Form::close(); ?>

                                <a href="<?php echo e(url('/assistant/service')); ?>" class="btn btn-warning">Cancel</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.assistantLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>