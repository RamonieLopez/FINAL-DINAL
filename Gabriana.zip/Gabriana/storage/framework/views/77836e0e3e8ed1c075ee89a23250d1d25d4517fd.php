<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            Re-schedule
        </h1>
        <ol class="breadcrumb">
            <li><a href="/assistant"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Schedule</li>
        </ol>
        <h4><?php echo e($schedule->patient->name); ?></h4>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body">
                        <?php if($errors->any()): ?>
                            <ul class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>

                        <?php echo Form::open(['action' => ['Assistant\\SchedulesController@update',  $schedule->schedId] ,'method' => 'POST']); ?>

                            <?php echo e(csrf_field()); ?>

                            <div class="form-group" <?php echo e($errors->has('patID') ? 'has-error' : ''); ?>>
                                <input type="hidden" name="patID" value="<?php echo e($schedule->patient->patID); ?>">
                            </div>
                            <div class="form-group" <?php echo e($errors->has('balance') ? 'has-error' : ''); ?>>
                                
                            </div>  
                            <div class="form-group" <?php echo e($errors->has('date') ? 'has-error' : ''); ?>>
                                <?php echo e(Form::label('date', 'Date of Schedule')); ?>

                                <?php echo e(Form::date('date', $schedule->date, ['class' => 'form-control'])); ?>

                            </div>
                            <div class="form-group" <?php echo e($errors->has('timeFrom') ? 'has-error' : ''); ?>>
                                <?php echo e(Form::label('timeFrom', 'Time From')); ?>

                                <?php echo e(Form::time('timeFrom', $schedule->timeFrom, ['class' => 'form-control'])); ?>

                            </div>
                            <div class="form-group" <?php echo e($errors->has('timeTo') ? 'has-error' : ''); ?>>
                                <?php echo e(Form::label('timeTo', 'Time To')); ?>

                                <?php echo e(Form::time('timeTo', $schedule->timeTo, ['class' => 'form-control', 'placeholder' => 'First name followed by Last Name'])); ?>

                            </div>
                            <div class="form-group" <?php echo e($errors->has('opStatus') ? 'has-error' : ''); ?>>
                                <?php echo e(Form::hidden('opStatus', 'Operation Status')); ?>

                                <?php echo e(Form::hidden('opStatus', 'Pending', ['class' => 'form-control'])); ?>

                            </div>
                            <div class="form-group" <?php echo e($errors->has('servID') ? 'has-error' : ''); ?>>
                                <?php echo e(Form::label('servID', 'Service')); ?>

                                <select name="servID" class="form-control">
                                    <option value="<?php echo e($schedule->service->servID); ?>"><?php echo e($schedule->service->servName); ?></option>
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($service->servID); ?>"><?php echo e($service->servName); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div> 
                            <div class="form-group" <?php echo e($errors->has('dentID') ? 'has-error' : ''); ?>> 
                                <?php echo e(Form::label('dentID', 'Dentist')); ?>                              
                                 <select name="dentID" class="form-control">
                                    <option value="<?php echo e($schedule->dentist->dentID); ?>"><?php echo e($schedule->dentist->name); ?></option> 
                                    <?php $__currentLoopData = $dentists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dentist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dentist->dentID); ?>"><?php echo e($dentist->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select> 
                            </div>
                            <?php echo e(Form::hidden('_method', 'PATCH')); ?>                     
                    </div>
                    <div class="box-footer">
                        <?php echo e(Form::submit('Submit', ['class'=>'btn btn-success pull-right'])); ?>


                    <?php echo Form::close(); ?>

                    <a href="<?php echo e(url('/assistant/schedules')); ?>" title="Back"><button class="btn btn-warning"> Cancel</button></a>
                    </div>   
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.assistantLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>