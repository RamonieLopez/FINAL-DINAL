<?php $__env->startSection('content'); ?>
<section class="content-header">
   <h1>
      <?php echo e($patient->name); ?>

   </h1>
   <ol class="breadcrumb">
      <li><a href=<?php echo e(url('/assistant')); ?>><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="<?php echo e(url('/assistant/patient')); ?>">Records</a></li>
   </ol>
</section>
<!-- Main content -->
<section class="content">
   <div class="row">
      <div class="col-md-12">
         <div class="box">
            <div class="box-header with-border">
               <h3 class="box-title">Patient Payment History</h3>
            </div>
            <div class="box box-solid">
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="box-group" id="accordion">
                        <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
                        <?php if(count($payments) > 0): ?>
                            <?php $counter = 0;?>
                            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $pID = $patient->patID; ?>
                            <?php if($payment->patID == $pID): ?>
                                <?php $counter++; ?>
                                <div class="panel box box-primary">
                                    <div class="box-header with-border">
                                        <h4 class="box-title">
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($counter); ?>" aria-expanded="true" class="collapsed"><?php echo e($payment->service->servName); ?></a>
                                        </h4>
                                    </div>
                                    <div id="collapse<?php echo e($counter); ?>" class="panel-collapse collapse in" aria-expanded="true" style="">
                                        <div class="box-body">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>Date of Payment</th>
                                                        <th>Amount</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td><?php echo e($payment->created_at); ?></td>
                                                        <td><?php echo e($payment->amount); ?></td>
                                                    </tr>
                                                </tbody>
                                                <tfoot>

                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <h1>
                                No Payment History Found! 
                            </h1>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
            <div class="box-footer">
               <a href="<?php echo e(url('/assistant/patient')); ?>" class="btn btn-warning">Back</a>
            </div>
         </div>
         <!-- /.box -->
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.assistantLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>