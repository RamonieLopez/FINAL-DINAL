<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            View Schedule
        </h1>
        <ol class="breadcrumb">
            <li><a href="/assistant"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Schedule</li>
        </ol>
        <h4><?php echo e($schedule->patient->name); ?></h4>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body">
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <th>Patient Name</th>
                                    <td><?php echo e($schedule->patient->name); ?></td>
                                </tr>
                                <tr>
                                    <th>Date of Schedule</th>
                                    <td><?php echo e($schedule->date); ?></td>
                                </tr>
                                <tr>
                                    <th>Time From</th>
                                    <td><?php echo e($schedule->timeFrom); ?></td>
                                </tr>
                                <tr>
                                    <th>Time To</th>
                                    <td><?php echo e($schedule->timeTo); ?></td>
                                </tr>
                                <tr>
                                    <th>Service Rendered</th>
                                    <td><?php echo e($schedule->service->servName); ?></td>
                                </tr>
                                <tr>
                                    <th>Price</th>
                                    <td><?php echo e($schedule->service->price); ?></td>
                                </tr>
                                <tr>
                                    <th>Dentist</th>
                                    <td><?php echo e($schedule->dentist->name); ?></td>
                                </tr>
                                <tr>
                                    <th>Teeth Affected</th>
                                    <td><?php echo e($schedule->teethID); ?></td>
                                </tr>
                            </tbody>
                       </table>
                    </div>
                    <div class="box-footer">
                        <a href="<?php echo e(url('/assistant/schedules/doneSchedules')); ?>" class="btn btn-warning">Back</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.assistantLayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>