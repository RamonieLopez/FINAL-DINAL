<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
           /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'payments';

    /**
    * The database primary key value.
    *
    * @var string
    */
    protected $primaryKey = 'paymentID';

    /**
     * Attributes that should be mass-assignable.
     *
     * @var array
     */
    protected $fillable = ['amount'];

    public function FunctionName(Type $var = null)
    {
        # code...
    }

    public function schedule()
    {
        return $this->belongsTo('App\Schedule');
    }

    public function patient()
    {
        return $this->belongsTo('App\Patient');
    }

    public function service()
    {
        return $this->belongsTo('App\Service', 'servID');
    }
}
