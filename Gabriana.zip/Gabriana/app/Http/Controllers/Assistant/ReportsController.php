<?php

namespace App\Http\Controllers\Assistant;

use App\Http\Controllers\Controller;
use App\Http\Requests;

use Illuminate\Http\Request;

use App\Schedule;
use App\Patient;
use App\Inventory;
use App\Stock;
use App\Service;
use App\Dentist;
use App\Payment;
use Carbon\Carbon;

class ReportsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function patientsToday()
    {   
        $today = Carbon::now()->toDateString();
        $schedules = Schedule::all();
        $inventory = Inventory::all();
        $payments = Payment::all();

        // foreach($payments as $payment){
        //     $pay = $payment->amount;
        //     print "$pay";
        // }

    


        return view('Assistant.Reports.patientsToday')
        ->with('schedules', $schedules)
        ->with('today', $today)
        ->with('payments', $payments)
        ->with('inventory', $inventory);
    }

    public function inventory()
    {   
        $inventory = Inventory::all();
        return view('Assistant.Reports.lowInStock')
        ->with('inventory', $inventory);
    }

}
