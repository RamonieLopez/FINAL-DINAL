<?php

namespace App\Http\Controllers\Admin;

use App\Http\Requests;
use App\Http\Controllers\Controller;

use App\Schedule;
use Illuminate\Http\Request;

use App\Patient;
use App\Service;
use App\Dentist;
use App\Teeth;
use App\Payment;

class SchedulesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index(Request $request)
    {
        $patients = Patient::all();
        $services = Service::all();
        $dentists = Dentist::all();
        
        $perPage = 25;
        $schedules = Schedule::paginate($perPage);
        // dd($schedules);
        return view('Admin.schedules.index', compact('schedules'));
    }

    public function done(Request $request)
    {
        $patients = Patient::all();
        $services = Service::all();
        $dentists = Dentist::all();

        $schedules = Schedule::all();
        // dd($schedules);
        return view('Admin.schedules.doneSchedules', compact('schedules'));
    }

    public function cancelled(Request $request)
    {
        $patients = Patient::all();
        $services = Service::all();
        $dentists = Dentist::all();

        $schedules = Schedule::all();
        // dd($schedules);
        return view('Admin.schedules.cancelledSchedules', compact('schedules'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        $services = Service::all();
        $dentists = Dentist::all();
        $patients = Patient::all();
        $teeth = Teeth::all();

        return view('Admin.schedules.create')
        ->with('services', $services)
        ->with('dentists', $dentists)
        ->with('teeth', $teeth)
        // ->with('balance', $balance)
        ->with('patients', $patients);
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function store(Request $request)
    {
        $this->validate($request, [
			'date' => 'required',
			'timeFrom' => 'required',
            'timeTo' => 'required',
            'opStatus',
            'dentID',
            'servID',
            'patID',
            'teethID',
            'balance'
            
        ]);
        
        $schedule = new Schedule;
        $schedule->date = $request->input('date');
        $schedule->timeFrom = $request->input('timeFrom');
        $schedule->timeTo = $request->input('timeTo');
        $schedule->opStatus = $request->input('opStatus');
        $schedule->dentID = $request->input('dentID');
        $schedule->servID = $request->input('servID');
        $schedule->teethID = $request->input('teethID');
        $schedule->patID = $request->input('patID');

        $service = Service::find($request->input('servID'));
        $balance = $service->price;
        $schedule->balance = $balance;

        $schedule->save();
        
        // dd($schedule->balance);

        // $paymentID = $schedule->payment->paymentID;
        // $payments = Payment::find($paymentID);
        
        // dd($requestData + ['balance', $balance]);
        return redirect('admin/schedules')->with('flash_message', 'Schedule added!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $schedID
     *
     * @return \Illuminate\View\View
     */
    public function show($schedId)
    {
        $patients = Patient::all();
        $services = Service::all();
        $dentists = Dentist::all();   
        $schedule = Schedule::findOrFail($schedId);
        // dd();
        return view('Admin.schedules.show', compact('schedule'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     *
     * @return \Illuminate\View\View
     */
    public function edit($schedId)
    {
        $services = Service::all();
        $dentists = Dentist::all();
        $schedule = Schedule::find($schedId);
        return view('Admin.schedules.edit', compact('schedule'))
        ->with('services',$services)
        ->with('dentists',$dentists);
    }

    public function view($schedId)
    {
        $services = Service::all();
        $dentists = Dentist::all();
        $patients = Patient::all();
        $teeth = Teeth::all();
        $schedule = Schedule::find($schedId);
        return view('Admin.schedules.schedule', compact('schedule'))
        ->with('services',$services)
        ->with('teeth', $teeth)
        ->with('patients', $patients)
        ->with('dentists',$dentists);
    }

    public function checkout($schedId)
    {
        $services = Service::all();
        $dentists = Dentist::all();
        $patients = Patient::all();
        $teeth = Teeth::all();
        $schedule = Schedule::find($schedId);
        return view('Admin.schedules.checkout', compact('schedule'))
        ->with('services',$services)
        ->with('teeth', $teeth)
        ->with('patients', $patients)
        ->with('dentists',$dentists);
    }

    public function ongoingView($schedId)
    {
        $services = Service::all();
        $dentists = Dentist::all();
        $patients = Patient::all();
        $teeth = Teeth::all();
        $schedule = Schedule::find($schedId);
        return view('Admin.schedules.ongoing', compact('schedule'))
        ->with('services',$services)
        ->with('teeth', $teeth)
        ->with('patients', $patients)
        ->with('dentists',$dentists);
    }

    
    public function ongoing(Request $request, $schedId)
    {
        $this->validate($request, [
			'date' => 'required',
			'timeFrom' => 'required',
            'timeTo' => 'required',
            'opStatus',
            'dentID',
            'servID',
            'patID',
            'teethID'
        ]);
        
        $requestData = $request->all();
        $schedule = Schedule::findOrFail($schedId);
        $patID = $schedule->patient->patID;
        $patients = Patient::find($patID);
        // $payments = new Payments;


        

        $balance = $patients->balance; // patient
        $servPrice = $schedule->balance; // sched balance
        $servPayment = $request->input('payment');
        $total = $servPrice - $servPayment;

        $schedule->opStatus = "Ongoing";
        
        $schedule->update($requestData);
        $schedule->balance = $total;        
        $schedule->save();

        $schedules = Schedule::all();
        $totalBalance = 0;
        foreach($schedules as $sched){
            if ($sched->patID == $patients->patID){
                $totalBalance = $totalBalance + $sched->balance;
            }  
        }
        $patients->balance = $totalBalance;
        
        $patients->save();

        $payment = new Payment;
        $payment->amount = $servPayment;
        $payment->schedId = $schedule->schedId;

        $payment->save();

        

        return redirect('admin/schedules')->with('success', 'Schedule Successfully Marked as Ongoing !');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function update(Request $request, $schedId)
    {
        $this->validate($request, [
			'date' => 'required',
			'timeFrom' => 'required',
            'timeTo' => 'required',
            'opStatus',
            'dentID',
            'servID',
            'patID',
            'teethID'
		]);
        $requestData = $request->all();
        
        $schedule = Schedule::findOrFail($schedId);
        $patID = $schedule->patient->patID;
        $patients = Patient::find($patID);

        // $paymentID = $schedule->payment->paymentID;
        // $payments = Payment::find($paymentID);
        

        // $balance = $patients->balance;
        // $servPrice = $schedule->service->price;
        // $payment = $schedule->payment;
        // $total = $servPrice - $payment;
        // $newBalance = $total + $balance;
   

        // $schedule->opStatus = "Done";
        // $patients->balance = $newBalance;
        // $patients->save();

        // $schedule->timeTo = 
        // $schedule->timeFrom =
        // $schedule->servID = 
        $schedule->update($requestData);

        // dd($payment);

        return redirect('admin/schedules')->with('flash_message', 'Schedule updated!');
    }

    public function pay(Request $request, $schedId)
    {
        $this->validate($request, [
			'date' => 'required',
			'timeFrom' => 'required',
            'timeTo' => 'required',
            'opStatus',
            'dentID',
            'servID',
            'patID',
            'teethID'
        ]);
        
        $requestData = $request->all();
        $schedule = Schedule::findOrFail($schedId);
        $patID = $schedule->patient->patID;
        $patients = Patient::find($patID);
        // $payments = new Payments;

        // $paymentID = $schedule->payment->paymentID;
        // $payments = Payment::find($paymentID);
        

        $balance = $patients->balance; // patient
        $servPrice = $schedule->balance; // sched balance
        $servPayment = $request->input('payment');
        $total = $servPrice - $servPayment;

        $schedule->opStatus = "Done";
        

        // $schedule->timeTo = 
        // $schedule->timeFrom =
        // $schedule->servID = 
        $schedule->update($requestData);
        $schedule->balance = $total;        
        $schedule->save();

        $schedules = Schedule::all();
        $totalBalance = 0;
        foreach($schedules as $sched){
            if ($sched->patID == $patients->patID){
                $totalBalance = $totalBalance + $sched->balance;
            }  
        }
        $patients->balance = $totalBalance;
        
        $patients->save();

        $payment = new Payment;
        $payment->amount = $servPayment;
        $payment->schedId = $schedule->schedId;

        $payment->save();


        return redirect('admin/schedules')->with('flash_message', 'Schedule updated!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     *
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    // public function destroy($schedId)
    // {
        
    //     $item = Schedule::find($schedId);

    //     $item->delete();

    //     return redirect('admin/schedules')->with('flash_message', 'Schedule deleted!');
    // }

    public function destroy($schedId)
    {
        $item = Schedule::find($schedId);
        $item->opStatus = "Cancelled";
        $item->save();

        return redirect('admin/schedules')->with('success', 'Schedule Cancelled !');
    }


    
}
