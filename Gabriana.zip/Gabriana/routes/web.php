<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Auth::routes();
// Route::group(['middleware'=>['auth']],function(){

    Route::post('/login/custom',[
        'uses' => 'LoginController@login',
        'as' => 'login.custom'
    ]);

    Route::get('/admin', 'PagesController@admin')->name('admin');
    Route::get('/assistant', 'PagesController@assistant')->name('assistant');
    Route::get('/', 'PagesController@log')->name('');
    
    Route::get('admin/inventory/{invID}/add', 'Admin\\InventoryController@add');
    Route::resource('admin/inventory', 'Admin\\InventoryController');
    
    Route::resource('admin/patient', 'Admin\\PatientsController');
    Route::resource('admin/inactiveInventory', 'Admin\\InactiveInventoryController');
    Route::resource('admin/inactivePatient', 'Admin\\InactivePatientsController');

    //Admin Schedules
    Route::get('admin/schedules/doneSchedules', 'Admin\\SchedulesController@done');
    Route::get('admin/schedules/cancelledSchedules', 'Admin\\SchedulesController@cancelled');
    Route::get('admin/schedules/{schedId}/checkout', 'Admin\\SchedulesController@checkout');
    Route::get('admin/schedules/{schedId}/view', 'Admin\\SchedulesController@view');
    Route::put('admin/schedules/{schedId}/ongoing', 'Admin\\SchedulesController@ongoing');
    Route::get('admin/schedules/{schedId}/ongoingView', 'Admin\\SchedulesController@ongoingView');
    Route::put('admin/schedules/{schedId}/pay', 'Admin\\SchedulesController@pay');
    Route::resource('admin/schedules', 'Admin\\SchedulesController');

    Route::resource('admin/service', 'Admin\\ServicesController');

    //Assistant Routes

    Route::get('assistant/inventory/{invID}/add', 'Assistant\\InventoryController@add');
    Route::get('assistant/inventory/{invID}/minus', 'Assistant\\InventoryController@minus');
    Route::put('assistant/inventory/{invID}/added', 'Assistant\\InventoryController@added');
    Route::put('assistant/inventory/{invID}/reduce', 'Assistant\\InventoryController@reduce');
    Route::get('assistant/inventory/goodItems', 'Assistant\\InventoryController@goodInv');
    Route::get('assistant/inventory/lowItems', 'Assistant\\InventoryController@lowInv');
    Route::get('assistant/inventory/noStockItems', 'Assistant\\InventoryController@noStockInv');
    Route::resource('assistant/inventory', 'Assistant\\InventoryController');
    Route::resource('assistant/inventory', 'Assistant\\InventoryController');
    Route::get('newStocks', function(){
        return view ('assistant/Inventory/newStocks');   
    });

    // Assistant Patient

    Route::get('assistant/patient/{patID}/pay', 'Assistant\\PatientsController@pay');
    Route::put('assistant/patient/{patID}/ongoing', 'Assistant\\PatientsController@ongoing');
    Route::get('assistant/patient/{patID}/payHistory', 'Assistant\\PatientsController@payHistory');
    Route::resource('assistant/patient', 'Assistant\\PatientsController');
    Route::resource('assistant/inactiveInventory', 'Assistant\\InactiveInventoryController');
    Route::resource('assistant/inactivePatient', 'Assistant\\InactivePatientsController');

    Route::get('assistant/schedules/doneSchedules', 'Assistant\\SchedulesController@done');
    Route::get('assistant/schedules/cancelledSchedules', 'Assistant\\SchedulesController@cancelled');
    Route::get('assistant/schedules/{schedId}/checkout', 'Assistant\\SchedulesController@checkout');
    Route::get('assistant/schedules/{schedId}/view', 'Assistant\\SchedulesController@view');
    Route::put('assistant/schedules/{schedId}/ongoing', 'Assistant\\SchedulesController@ongoing');
    Route::get('assistant/schedules/{schedId}/ongoingView', 'Assistant\\SchedulesController@ongoingView');
    Route::put('assistant/schedules/{schedId}/pay', 'Assistant\\SchedulesController@pay');
    Route::resource('assistant/schedules', 'Assistant\\SchedulesController');
    
    Route::resource('assistant/service', 'Assistant\\ServicesController');

    
    Route::get('assistant/reports/patients', 'Assistant\\ReportsController@patientsToday');
    Route::get('assistant/reports/inventory', 'Assistant\\ReportsController@inventory');

    Route::get('assistant/patient/{patID}/history', 'Assistant\\PatientsController@teethHistory');

    Route::get('admin/patient/{patID}/history', 'Admin\\PatientsController@teethHistory');

    Route::get('admin/patient/{patID}/payHistory', 'Admin\\PatientsController@payHistory');
    
// });