@extends('layouts.assistantLayout')
@section('content')

<!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
	    Low in Stock
	</h1>
	<ol class="breadcrumb">
        <li><a href="{{ url('/assistant') }}"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="">Inventory</li>
        <li class="active">Reports</li>
    </ol>
</section>
<section class="content">
	<div class="row">
        <div class="col-xs-12">
            <div class="box">
            <!-- /.box-header -->
                <div class="box-body">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Inventory Name</th>
                                <th>Quantity</th>
                                <th>Unit</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(count($inventory) > 1)
                                @foreach($inventory as $item)
                                    @if($item->invStatus == 'Low in Stock')
                                        <tr>
                                            <td>{{$item->invName}}</td>
                                            <td>{{$item->quantity}}</td>
                                            <td>{{$item->unit}}</td>
                                        </tr>
                                    @endif
                                @endforeach
                            @else
                                <p>No Inventory Found</p>
                            @endif                                
                        </tbody>
                    </table>

                </div>
                
            </div>
        </div>
    </div>
</section>


@endsection