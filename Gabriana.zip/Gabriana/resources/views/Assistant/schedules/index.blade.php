<?php 
    use App\Http\Controllers\Assistant\SchedulesController;
?>
@extends('layouts.assistantLayout')

@section('content')
    <section class="content-header">
        <h1>
           Active Schedules
        </h1>
        <ol class="breadcrumb">
            <li><a href="/assistant"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Schedule</li>
        </ol>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <a href="{{ url('/assistant/schedules/create') }}" class="btn btn-success" title="Add New Schedule">
                    <i class="fa fa-plus" aria-hidden="true"></i> &nbsp; Create New Schedule
                </a>
                <br>
                <br>
                <div class="box">
                <div class="box-body">
                    {{-- <form method="GET" action="{{ url('/assistant/schedules') }}" accept-charset="UTF-8" class="form-inline my-2 my-lg-0 float-right" role="search">
                        <div class="input-group pull-right">
                            <input type="text" class="form-control" name="search" placeholder="Search..." value="{{ request('search') }}">
                        </div>
                        <span class="input-group-append pull-right">
                            <button class="btn btn-secondary" type="submit">
                                <i class="fa fa-search"></i>
                            </button>
                        </span>
                    </form> --}}
                    <br>
                    <br>
                    <div>
                        <table id="example2" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Patient Name</th>
                                    <th>Date of Schedule</th>
                                    <th>Time From</th>
                                    <th>Time To</th>
                                    <th>Services</th>
                                    <th>Dentist</th>
                                    <th><center>Actions</center></th>
                                </tr>
                            </thead>
                            <tbody>
                            @foreach($schedules as $item)
                            @if($item->opStatus == 'Pending')
                                <tr>
                                    <td>{{ $item->patient->name }}</td>
                                    <td>{{ $item->date }}</td>
                                    <td>{{ $item->timeFrom }}</td>
                                    <td>{{ $item->timeTo }}</td>
                                    <td>{{ $item->service->servName }}</td>
                                    <td>{{ $item->dentist->name }}</td>
                                    <td>
                                        <center>
                                        <a href="{{ url('/assistant/schedules/' . $item->schedId . '/edit') }}" title="Edit Schedule"><button class="btn btn-primary btn-sm" onclick="return confirm(&quot;Confirm delete?&quot;"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Reschedule</button></a>
                                        <a href="{{ url('/assistant/schedules/' . $item->schedId . '/checkout') }}" title="Finish"><button class="btn btn-success btn-sm"><i class="fa fa-check" aria-hidden="true"></i> Finish</button></a>
                                        <a href="{{ url('/assistant/schedules/' . $item->schedId . '/ongoingView') }}" title="Mark as Ongoing"><button class="btn btn-primary btn-sm" onclick="return confirm(&quot;Confirm delete?&quot;"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Ongoing</button></a>
                                        {!! Form::open(['action' => ['Assistant\SchedulesController@destroy', $item->schedId], 'method' => 'POST', 'style' => 'display:inline']) !!}
                                            {{Form::hidden('_method', 'DELETE')}}
                                            <button class="btn btn-danger btn-sm" type="submit"><i class="fa fa-trash"></i> Cancel</button>
                                        {!! Form::close() !!}
                                    </center>
                                    </td>
                                </tr>
                                @endif
                            @endforeach
                            </tbody>
                        </table>
                        {{-- <div class="pagination-wrapper"> {!! $schedules->appends(['search' => Request::get('search')])->render() !!} </div> --}}
                    </div>

                    
                </div>
            </div>
            </div>
        </div>

        <section class="content-header">
            <h1>
                Ongoing Service
            </h1>
        </section>
        <div class="row">
            <div class="col-xs-12">
                <br>
                <br>
                <div class="box">
                <div class="box-body">
                    {{-- <form method="GET" action="{{ url('/assistant/schedules') }}" accept-charset="UTF-8" class="form-inline my-2 my-lg-0 float-right" role="search">
                        <div class="input-group pull-right">
                            <input type="text" class="form-control" name="search" placeholder="Search..." value="{{ request('search') }}">
                        </div>
                        <span class="input-group-append pull-right">
                            <button class="btn btn-secondary" type="submit">
                                <i class="fa fa-search"></i>
                            </button>
                        </span>
                    </form> --}}
                    <br>
                    <br>
                        <table id="example1" class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>Patient Name</th>
                                    <th>Services</th>
                                    <th>Dentist</th>
                                    <th><center>Actions</center></th>
                                </tr>
                            </thead>
                            <tbody>
                            @foreach($schedules as $item)
                            @if($item->opStatus == 'Ongoing')
                                <tr>
                                    <td>{{ $item->patient->name }}</td>
                                    <td>{{ $item->service->servName }}</td>
                                    <td>{{ $item->dentist->name }}</td>
                                    <td>
                                        <center>
                                        <a href="{{ url('/assistant/schedules/' . $item->schedId . '/edit') }}" title="View Schedule"><button class="btn btn-primary btn-sm" onclick="return confirm(&quot;Confirm delete?&quot;"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Reschedule</button></a>
                                    </center>
                                    </td>
                                </tr>
                                @endif
                            @endforeach
                            </tbody>
                        </table>
                        {{-- <div class="pagination-wrapper"> {!! $schedules->appends(['search' => Request::get('search')])->render() !!} </div> --}}

                    
                </div>
                </div>
            </div>
        </div>
    </section>
    <script>
        $(document).ready(function() {
            $('#example2').DataTable( {
                "order": [[ 1, "asc" ]]
            } );
        } );
    </script>
@endsection
