@extends('layouts.assistantLayout')
@section('content')

<section class="content-header">
    <h1>
       Cancelled Schedules
    </h1>
    <ol class="breadcrumb">
        <li><a href="/assistant"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Schedule</li>
    </ol>
</section>
<section class="content">
    <div class="row">
        <div class="col-xs-12">
            <br>
            <br>
            <div class="box">
            <div class="box-body">
                {{-- <form method="GET" action="{{ url('/assistant/schedules') }}" accept-charset="UTF-8" class="form-inline my-2 my-lg-0 float-right" role="search">
                    <div class="input-group pull-right">
                        <input type="text" class="form-control" name="search" placeholder="Search..." value="{{ request('search') }}">
                    </div>
                    <span class="input-group-append pull-right">
                        <button class="btn btn-secondary" type="submit">
                            <i class="fa fa-search"></i>
                        </button>
                    </span>
                </form> --}}
                <br>
                <br>
                <div>
                    <table id="example1" class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>Patient Name</th>
                                <th>Date of Schedule</th>
                                <th>Services</th>
                                <th>Dentist</th>
                                <th><center>Actions</center></th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach($schedules as $item)
                        @if($item->opStatus == 'Cancelled')
                            <tr>
                                <td>{{ $item->patient->name }}</td>
                                <td>{{ $item->date }}</td>
                                <td>{{ $item->service->servName }}</td>
                                <td>{{ $item->dentist->name }}</td>
                                <td>
                                    <center>
                                    <a href="{{ url('/assistant/schedules/' . $item->schedId . '/view') }}" title="View Schedule"><button class="btn btn-success btn-sm" onclick="return confirm(&quot;Confirm delete?&quot;"><i class="fa fa-check" aria-hidden="true"></i> View</button></a>

                                </center>
                                </td>
                            </tr>
                            @endif
                        @endforeach
                        </tbody>
                    </table>
                    {{-- <div class="pagination-wrapper"> {!! $schedules->appends(['search' => Request::get('search')])->render() !!} </div> --}}
                </div>

                
            </div>
        </div>
        </div>
    </div>
</section>

@endsection