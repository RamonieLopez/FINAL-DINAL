@extends('layouts.assistantLayout')
@section('content')
<section class="content-header">
   <h1>
      {{$patient->name}}
   </h1>
   <ol class="breadcrumb">
      <li><a href={{ url('/assistant') }}><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="{{ url('/assistant/patient') }}">Records</a></li>
   </ol>
</section>
<!-- Main content -->
<section class="content">
   <div class="row">
      <div class="col-md-12">
         <div class="box">
            <div class="box-header with-border">
               <h3 class="box-title">Schedules</h3>
            </div>                
            <div class="box-body">
                <table id="example1" class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Services</th>
                            <th>Dentist</th>
                            <th>Balance</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $counter = 0 ?>
                    @foreach($schedules as $item)
                    @if($item->opStatus == 'Ongoing')
                        <?php $counter++ ?>
                        <tr>
                            <td>{{ $item->date }}</td>
                            <td>{{ $item->service->servName }}</td>
                            <td>{{ $item->dentist->name }}</td>
                            <td>{{ $item->balance}}</td>
                            <td>
                                <button class="btn btn-success btn-sm" style="margin: 2px" data-toggle="modal" data-target="#modalCart{{$counter}}" ><i class="fa fa-check" ></i>&nbsp;Pay</button>
                                <div class="modal fade" id="modalCart{{$counter}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <!--Header-->
                                            <div class="modal-header">
                                                <h1 class="modal-title" id="myModalLabel">{{$patient->name}}</h1>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">×</span>
                                                </button>
                                            </div>
                                            <!--Body-->
                                            <div class="modal-body">
                                                <h3>{{$item->service->servName}}</h3>
                                                {!! Form::open(['action' => ['Assistant\\PatientsController@ongoing',  $item->schedId], 'method' => 'POST']) !!}
                                                    <div class="form-group" {{ $errors->has('patID') ? 'has-error' : ''}}>
                                                        <input type="hidden" name="patID" value="{{$item->patient->patID}}">
                                                    </div>
                                                    <div class="form-group" {{ $errors->has('dentID') ? 'has-error' : ''}}>
                                                        <input type="hidden" name="dentID" value="{{$item->dentist->dentID}}">
                                                    </div>
                                                    <div class="form-group" {{ $errors->has('date') ? 'has-error' : ''}}>
                                                        <input type="hidden" name="date" value="{{$item->date}}">
                                                    </div>
                                                    <div class="form-group" {{ $errors->has('timeFrom') ? 'has-error' : ''}}>
                                                        <input type="hidden" name="timeFrom" value="{{$item->timeFrom}}">
                                                    </div>
                                                    <div class="form-group" {{ $errors->has('timeTo') ? 'has-error' : ''}}>
                                                        <input type="hidden" name="timeTo" value="{{$item->timeTo}}">
                                                    </div>
                                                    <div class="form-group" {{ $errors->has('teethID') ? 'has-error' : ''}}>
                                                        <input type="hidden" name="teethID" value="{{$item->teethID}}">
                                                    </div>
                                                    <div class="form-group" {{ $errors->has('servID') ? 'has-error' : ''}}>
                                                        <input type="hidden" name="servID" value="{{$item->servID}}">
                                                    </div>     
                                                    <div class="form-group">
                                                        {{Form::label('price', 'Amount to be Paid')}}
                                                        {{Form::text('price', $item->balance, ['class' => 'form-control', 'placeholder' => 'Total price of services'])}}
                                                    </div>
                                                    <div class="form-group">
                                                        {{Form::label('payment', 'Payment')}}
                                                        {{Form::text('payment', '', ['class' => 'form-control', 'placeholder' => 'Payment Amount'])}}
                                                    </div>
                                                {{Form::hidden('_method', 'PUT')}}
                                            </div>
                                            <!--Footer-->
                                            <div class="modal-footer">
                                                {{Form::submit('Pay', ['class'=>'btn btn-success pull-right']) }}
                                            {!! Form::close() !!}
                                            
                                                <button type="button" class="btn btn-warning pull-left" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        @endif
                    @endforeach
                    </tbody>
                </table>
            </div>
            <div class="box-footer">
                <a href="{{ url('/assistant/patient'. '/' .$patient->patID) }}" class="btn btn-warning">Back</a>
             </div>
         </div>
         <!-- /.box -->
      </div>
   </div>
</section>
@endsection


