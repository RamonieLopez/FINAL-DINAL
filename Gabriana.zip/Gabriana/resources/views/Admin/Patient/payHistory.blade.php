@extends('layouts.adminLayout')
@section('content')
<section class="content-header">
   <h1>
      {{$patient->name}}
   </h1>
   <ol class="breadcrumb">
      <li><a href={{ url('/admin') }}><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="{{ url('/admin/patient') }}">Records</a></li>
   </ol>
</section>
<!-- Main content -->
<section class="content">
   <div class="row">
      <div class="col-md-12">
         <div class="box">
            <div class="box-header with-border">
               <h3 class="box-title">Patient Payment History</h3>
            </div>
            <div class="box box-solid">
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="box-group" id="accordion">
                        <!-- we are adding the .panel class so bootstrap.js collapse plugin detects it -->
                        @if(count($payments) > 0)
                            <?php $counter = 0;?>
                            @foreach($payments as $payment)
                            <?php $pID = $patient->patID; ?>
                            @if($payment->patID == $pID)
                                <?php $counter++; ?>
                                <div class="panel box box-primary">
                                    <div class="box-header with-border">
                                        <h4 class="box-title">
                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse{{$counter}}" aria-expanded="true" class="collapsed">{{$payment->service->servName}}</a>
                                        </h4>
                                    </div>
                                    <div id="collapse{{$counter}}" class="panel-collapse collapse in" aria-expanded="true" style="">
                                        <div class="box-body">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>Date of Payment</th>
                                                        <th>Amount</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr>
                                                        <td>{{$payment->created_at}}</td>
                                                        <td>{{$payment->amount}}</td>
                                                    </tr>
                                                </tbody>
                                                <tfoot>

                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            @endif
                            @endforeach
                        @else
                            <h1>
                                No Payment History Found! 
                            </h1>
                        @endif
                    </div>
                </div>
                <!-- /.box-body -->
            </div>
            <!-- /.box -->
            <div class="box-footer">
               <a href="{{ url('/admin/patient') }}" class="btn btn-warning">Back</a>
            </div>
         </div>
         <!-- /.box -->
      </div>
   </div>
</section>
@endsection





