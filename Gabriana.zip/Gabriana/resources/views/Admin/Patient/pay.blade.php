@extends('layouts.adminLayout')
@section('content')
<section class="content-header">
   <h1>
      {{$patient->name}}
   </h1>
   <ol class="breadcrumb">
      <li><a href={{ url('/admin') }}><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="{{ url('/admin/patient') }}">Records</a></li>
   </ol>
</section>
<!-- Main content -->
<section class="content">
   <div class="row">
      <div class="col-md-12">
         <div class="box">
            <div class="box-header with-border">
               <h3 class="box-title">Schedules</h3>
            </div>

         </div>
         <!-- /.box -->
      </div>
   </div>
</section>
@endsection


