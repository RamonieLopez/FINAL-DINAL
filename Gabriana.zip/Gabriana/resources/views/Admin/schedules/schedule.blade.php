@extends('layouts.adminLayout')

@section('content')
    <section class="content-header">
        <h1>
            View Schedule
        </h1>
        <ol class="breadcrumb">
            <li><a href="/admin"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Schedule</li>
        </ol>
        <h4>{{$schedule->patient->name}}</h4>
    </section>
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <div class="box-body">
                        <table class="table table-bordered">
                            <tbody>
                                <tr>
                                    <th>Patient Name</th>
                                    <td>{{$schedule->patient->name}}</td>
                                </tr>
                                <tr>
                                    <th>Date</th>
                                    <td>{{$schedule->date}}</td>
                                </tr>
                                <tr>
                                    <th>Time From</th>
                                    <td>{{$schedule->timeFrom}}</td>
                                </tr>
                                <tr>
                                    <th>Time To</th>
                                    <td>{{$schedule->timeTo}}</td>
                                </tr>
                                <tr>
                                    <th>Service Rendered</th>
                                    <td>{{$schedule->service->servName}}</td>
                                </tr>
                                <tr>
                                    <th>Price</th>
                                    <td>{{$schedule->service->price}}</td>
                                </tr>
                                <tr>
                                    <th>Dentist</th>
                                    <td>{{$schedule->dentist->name}}</td>
                                </tr>
                                <tr>
                                    <th>Teeth Affected</th>
                                    <td>{{$schedule->teethID}}</td>
                                </tr>
                            </tbody>
                       </table>
                    </div>
                    <div class="box-footer">
                        <a href="{{ url('/admin/schedules/doneSchedules') }}" class="btn btn-warning">Back</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
